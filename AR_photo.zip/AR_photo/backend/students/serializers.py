from rest_framework import serializers
from .models import Student


class StudentSerializer(serializers.ModelSerializer):
    photo_url = serializers.SerializerMethodField()
    video_url = serializers.SerializerMethodField()
    pattern_url = serializers.SerializerMethodField()

    class Meta:
        model = Student
        fields = ['id', 'full_name', 'class_name', 'photo_url', 'video_url', 'pattern_url']

    def get_photo_url(self, obj):
        request = self.context.get('request')
        if obj.photo and request:
            return request.build_absolute_uri(obj.photo.url)
        return None

    def get_video_url(self, obj):
        request = self.context.get('request')
        if obj.video and request:
            return request.build_absolute_uri(obj.video.url)
        return None

    def get_pattern_url(self, obj):
        request = self.context.get('request')
        if obj.pattern_file and request:
            return request.build_absolute_uri(obj.pattern_file.url)
        return None
