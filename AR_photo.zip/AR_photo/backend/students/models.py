from django.db import models


class Student(models.Model):
    full_name = models.CharField(max_length=255, verbose_name="To'liq ism")
    class_name = models.CharField(max_length=50, verbose_name="Sinf", default="11-A")
    photo = models.ImageField(upload_to='students/photos/', verbose_name="Rasm")
    video = models.FileField(upload_to='students/videos/', verbose_name="Video")
    pattern_file = models.FileField(upload_to='students/patterns/', verbose_name="AR Pattern (.patt)")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Yaratilgan vaqt")

    class Meta:
        verbose_name = "O'quvchi"
        verbose_name_plural = "O'quvchilar"
        ordering = ['full_name']

    def __str__(self):
        return f"{self.full_name} — {self.class_name}"
