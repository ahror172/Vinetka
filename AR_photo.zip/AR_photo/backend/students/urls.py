from django.urls import path
from django.views.generic import TemplateView
from .views import StudentListAPIView
from . import admin_views

urlpatterns = [
    # Frontend (O'quvchilar uchun)
    path('', TemplateView.as_view(template_name='frontend/index.html'), name='home'),
    path('vinetka/', TemplateView.as_view(template_name='frontend/vinetka.html'), name='vinetka'),
    path('scan/', TemplateView.as_view(template_name='frontend/scan.html'), name='scan'),

    # API
    path('api/students/', StudentListAPIView.as_view(), name='student_list_api'),

    # Admin Panel
    path('admin-panel/', admin_views.admin_dashboard, name='admin_dashboard'),
    path('admin-panel/login/', admin_views.admin_login, name='admin_login'),
    path('admin-panel/logout/', admin_views.admin_logout, name='admin_logout'),
    path('admin-panel/student/add/', admin_views.admin_add_student, name='admin_add_student'),
    path('admin-panel/student/<int:pk>/edit/', admin_views.admin_edit_student, name='admin_edit_student'),
    path('admin-panel/student/<int:pk>/delete/', admin_views.admin_delete_student, name='admin_delete_student'),
]
