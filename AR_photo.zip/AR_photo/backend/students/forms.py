from django import forms
from .models import Student


class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['full_name', 'class_name', 'photo', 'video', 'pattern_file']
        widgets = {
            'full_name': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': "O'quvchining to'liq ismini kiriting"
            }),
            'class_name': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': "Masalan: 11-A"
            }),
            'photo': forms.FileInput(attrs={
                'class': 'form-file',
                'accept': 'image/*'
            }),
            'video': forms.FileInput(attrs={
                'class': 'form-file',
                'accept': 'video/*'
            }),
            'pattern_file': forms.FileInput(attrs={
                'class': 'form-file',
                'accept': '.patt'
            }),
        }
