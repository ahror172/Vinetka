from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Student
from .forms import StudentForm


def admin_login(request):
    """Admin kirish sahifasi"""
    if request.user.is_authenticated:
        return redirect('admin_dashboard')

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('admin_dashboard')
        else:
            messages.error(request, "Login yoki parol noto'g'ri!")

    return render(request, 'admin_panel/login.html')


def admin_logout(request):
    """Admin chiqish"""
    logout(request)
    return redirect('admin_login')


@login_required(login_url='admin_login')
def admin_dashboard(request):
    """Admin bosh sahifasi — statistika va o'quvchilar"""
    students = Student.objects.all()
    total_students = students.count()
    classes = Student.objects.values_list('class_name', flat=True).distinct()
    total_classes = classes.count()

    # Sinf bo'yicha statistika
    class_stats = []
    for cls in classes:
        count = Student.objects.filter(class_name=cls).count()
        class_stats.append({'name': cls, 'count': count})

    context = {
        'students': students,
        'total_students': total_students,
        'total_classes': total_classes,
        'class_stats': class_stats,
    }
    return render(request, 'admin_panel/dashboard.html', context)


@login_required(login_url='admin_login')
def admin_add_student(request):
    """Yangi o'quvchi qo'shish"""
    if request.method == 'POST':
        form = StudentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "O'quvchi muvaffaqiyatli qo'shildi!")
            return redirect('admin_dashboard')
    else:
        form = StudentForm()

    return render(request, 'admin_panel/student_form.html', {
        'form': form,
        'title': "Yangi o'quvchi qo'shish",
        'button_text': "Qo'shish"
    })


@login_required(login_url='admin_login')
def admin_edit_student(request, pk):
    """O'quvchini tahrirlash"""
    student = get_object_or_404(Student, pk=pk)
    if request.method == 'POST':
        form = StudentForm(request.POST, request.FILES, instance=student)
        if form.is_valid():
            form.save()
            messages.success(request, "O'quvchi ma'lumotlari yangilandi!")
            return redirect('admin_dashboard')
    else:
        form = StudentForm(instance=student)

    return render(request, 'admin_panel/student_form.html', {
        'form': form,
        'title': "O'quvchini tahrirlash",
        'button_text': "Saqlash",
        'student': student
    })


@login_required(login_url='admin_login')
def admin_delete_student(request, pk):
    """O'quvchini o'chirish"""
    student = get_object_or_404(Student, pk=pk)
    if request.method == 'POST':
        student.delete()
        messages.success(request, "O'quvchi o'chirildi!")
    return redirect('admin_dashboard')
