from rest_framework import generics
from .models import Student
from .serializers import StudentSerializer


class StudentListAPIView(generics.ListAPIView):
    """Barcha o'quvchilar ro'yxatini JSON formatda qaytaradi"""
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
